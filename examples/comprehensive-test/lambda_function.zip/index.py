import json
import os

def handler(event, context):
    """
    Simple Lambda function for testing
    """
    environment = os.environ.get('ENVIRONMENT', 'unknown')
    
    return {
        'statusCode': 200,
        'headers': {
            'Content-Type': 'application/json'
        },
        'body': json.dumps({
            'message': 'DeepDrift Test API',
            'environment': environment,
            'version': '1.0.0'
        })
    }
